import React, { useState, useEffect } from 'react';
import { collection, getDocs, updateDoc, doc } from 'firebase/firestore';
import { db } from './firebase';
import { toast } from 'react-toastify';
import { Modal, Form } from 'react-bootstrap'; // Import React-Bootstrap components
import SideNav from './SideNav'; // Import SideNav component
import CountdownLoader from './CountdownLoader'; // Import CountdownLoader component
import 'bootstrap/dist/css/bootstrap.min.css';
import './PaymentConfirmationPage.css'; // Import custom CSS

const PaymentConfirmationPage = () => {
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [emailFilter, setEmailFilter] = useState(''); // State for email filter

  useEffect(() => {
    const fetchPayments = async () => {
      try {
        const querySnapshot = await getDocs(collection(db, 'payments'));
        const paymentsList = querySnapshot.docs.map((doc) => {
          const data = doc.data();
          const date = data.date;
          return {
            id: doc.id,
            ...data,
            date: date ? (date.toDate ? date.toDate() : new Date(date)) : null // Handle date
          };
        });
        setPayments(paymentsList);
      } catch (error) {
        toast.error('Error fetching payments: ' + error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchPayments();
  }, []);

  const handlePaymentStatusChange = async (paymentId, newStatus) => {
    try {
      await updateDoc(doc(db, 'payments', paymentId), { status: newStatus });
      setPayments(payments.map((payment) =>
        payment.id === paymentId ? { ...payment, status: newStatus } : payment
      ));
      toast.success('Payment status updated successfully');
    } catch (error) {
      toast.error('Error updating payment status: ' + error.message);
    }
  };

  const filteredPayments = payments.filter(payment =>
    (payment.email || '').toLowerCase().includes(emailFilter.toLowerCase())
  );

  if (loading) return <CountdownLoader />; // Show loader while loading

  return (
    <div className="d-flex">
      <SideNav /> {/* Include the SideNav component */}
      <div className="content-wrapper">
        <h2 className="text-center">User Payment Confirmation</h2>

        {/* Email Filter Input */}
        <Form.Group controlId="emailFilter" className="mb-3">
          <Form.Label>Filter by Email:</Form.Label>
          <Form.Control
            type="text"
            placeholder="Enter email"
            value={emailFilter}
            onChange={(e) => setEmailFilter(e.target.value)}
          />
        </Form.Group>

        <div className="table-responsive">
          <table className="table table-bordered table-striped mt-4">
            <thead>
              <tr>
                <th>Email</th>
                <th>Deposited By</th>
                <th>Transaction Reference Number</th>
                <th>Date</th>
                <th>Bank Name</th>
                <th>Bank Branch</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {filteredPayments.map((payment) => (
                <tr key={payment.id}>
                  <td>{payment.email || 'N/A'}</td> {/* Display the email column */}
                  <td>{payment.depositedBy}</td>
                  <td>{payment.transactionRef}</td>
                  <td>{payment.date ? new Date(payment.date).toLocaleDateString() : 'N/A'}</td>
                  <td>{payment.bankName}</td> {/* Bank Name column */}
                  <td>{payment.bankBranch}</td> {/* Bank Branch column */}
                  <td>
                    <select
                      className="form-select"
                      value={payment.status || 'Pending'}
                      onChange={(e) => handlePaymentStatusChange(payment.id, e.target.value)}
                    >
                      <option value="Pending">Pending</option>
                      <option value="Received">Received</option>
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default PaymentConfirmationPage;
