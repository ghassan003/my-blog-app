const firebaseConfig = {
    // Your Firebase project configuration
    apiKey: '<API_KEY>',
    authDomain: '<AUTH_DOMAIN>',
    projectId: '<PROJECT_ID>',
  };
  
  export default firebaseConfig;